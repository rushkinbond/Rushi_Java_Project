package JAVAAA;

import java.awt.*;
import javax.swing.*;
 //import JAVAAA.Frontpagee;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

class Admin_vieww implements ActionListener
{
	JFrame f ;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
	JButton b1,b2,b3;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;

	public Admin_vieww()
	{
		 f = new JFrame("Front page");
		l1 = new JLabel("EVENT MANAGMENT SYSTEM");
		l7 = new JLabel("EVENT_TYPE:-");
		l2 = new JLabel("VENUE:-");
		l8 = new JLabel("FOOD:-");
		l3 = new JLabel("SUBEVENT:-");
		l5 = new JLabel("Total PEOPLE:-");
		l6 = new JLabel("DATE:-");
		l9 = new JLabel("NAME:-");
		l10 = new JLabel("PHONE NO:-");
		l4 = new JLabel();
		l4.setText("THE RECENT ORDER YOU HAVE GOT IS:-");
		l1.setFont(new Font("Serif", Font.PLAIN, 35));
		l4.setFont(new Font("Serif", Font.PLAIN, 20));
		l7.setFont(new Font("Serif", Font.PLAIN, 18));
		l2.setFont(new Font("Serif", Font.PLAIN, 18));
		l8.setFont(new Font("Serif", Font.PLAIN, 18));
		l3.setFont(new Font("Serif", Font.PLAIN, 18));
		l5.setFont(new Font("Serif", Font.PLAIN, 18));
		l6.setFont(new Font("Serif", Font.PLAIN, 18));
		l9.setFont(new Font("Serif", Font.PLAIN, 18));
		l10.setFont(new Font("Serif", Font.PLAIN, 18));
	//	b1.setFont(new Font("Serif", Font.PLAIN, 18));
		b1 = new JButton("VIEW EVENT");
		b2 = new JButton("Go back");
		b3 = new JButton("VIEW CUSTOMER DEATAILS");
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		t1 = new JTextField();
		t2 = new JTextField();
		t3 = new JTextField();
		t4 = new JTextField();
		t5 = new JTextField();
		t6 = new JTextField();
		t7 = new JTextField();
		t8 = new JTextField();

		l1.setBounds(130,30,600,30);
		l4.setBounds(180,80,470,30);
		l7.setBounds(150,200,200,30);
		l2.setBounds(150,240,200,30);
		l8.setBounds(150,280,200,30);
		l3.setBounds(150,320,200,30);
		l5.setBounds(150,360,200,30);
		l6.setBounds(150,400,200,30);
		t1.setBounds(350,200,150,30);
		t2.setBounds(350,240,150,30);
		t3.setBounds(350,280,150,30);
		t4.setBounds(350,320,150,30);
		t5.setBounds(350,360,150,30);
		t6.setBounds(350,400,150,30);
		b1.setBounds(180,450,150,30);
		b2.setBounds(410,450,100,30);
		l9.setBounds(150,160,200,30);
		l10.setBounds(150,120,200,30);
		t7.setBounds(350,160,150,30);
		t8.setBounds(350,120,150,30);
		b3.setBounds(250,500,200,30);
		
		
		f.add(l1);
		f.add(b1);
		f.add(b2);
		f.add(l2);
		f.add(l3);
		f.add(l4);
		f.add(t1);
		f.add(t2);
		f.add(l6);
		f.add(l5);
		f.add(l7);
		f.add(l8);
		f.add(t3);
		f.add(t4);
		f.add(t5);
		f.add(t6);
		f.add(l9);
		f.add(l10);
		f.add(t7);
		f.add(t8);
		f.add(b3);

		
		
		


		f.getContentPane().setBackground(Color.orange);
		f.setLayout(null);
		f.setSize(800,600);
		f.setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
	/*	if(e.getSource() == b2)
		{
			Homepagee abb = new Homepagee();
			abb.setVisible(true);
		}*/
		Connection c = null;
		Statement stmt = null;
	        if (e.getSource() == b1)
	        {   
	        	try 
	        	{
	        		Class.forName("org.postgresql.Driver");
	   	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Rushi123");
	   	         System.out.println("Opened database successfully");
	   	         stmt =c.createStatement();
	            String str = "select event_type,venue,food,subevent,total_people,date from final_selection";
	            ResultSet rs = stmt.executeQuery(str);
	            System.out.println(rs);

	            while (rs.next()) {
	            String event = rs.getString("event_type");
	            t1.setText(event);
	            String venue = rs.getString("venue");
	            t2.setText(venue);
	            String food = rs.getString("food");
	            t3.setText(food);
	            String subevent = rs.getString("subevent");
	            t4.setText(subevent);
	            String total_people = rs.getString("total_people");
	            t5.setText(total_people);
	            String date = rs.getString("date");
	            t6.setText(date);
	        	}
	        	}
	        	catch (Exception f)
	        	{
                    System.out.println(f.getMessage());
                }  
	        }
	if(e.getSource() == b2)
		{
			f.setVisible(false);
		}
	if(e.getSource() == b3)
	{
		try 
    	{
    		Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Rushi123");
	         System.out.println("Opened database successfully");
	         stmt =c.createStatement();
	         String str = "select age,name from login_details";
	         ResultSet rs = stmt.executeQuery(str);
	         System.out.println(rs);

	         while (rs.next()) 
	         {
	        	 String phonenumber = rs.getString("age");
 	        	 t8.setText(phonenumber);
 	        	 String name = rs.getString("name");
 	        	 t7.setText(name);
	         }
    	}
    	catch (Exception f)
    	{
            System.out.println(f.getMessage());
        } 
	}
	}


}

public class Admin_view
{
	public static void main(String[] args) 
	{
		Admin_vieww ab = new Admin_vieww();
	}

}