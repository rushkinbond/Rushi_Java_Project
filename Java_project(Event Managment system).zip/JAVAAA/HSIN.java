package JAVAAA;

class HSINN
{
/*	HSINN()
	{
//		Contact ab = new Contact();
	}*/
}

public class HSIN {
	public static void main(String[] args)

	{

		String S1= "Java String Quiz";

//		S1.charAt(S1.toUpperCase().length()));

	}	

}
